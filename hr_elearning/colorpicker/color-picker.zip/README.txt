A Pen created at CodePen.io. You can find this one at http://codepen.io/dariocorsi/pen/WwOWPE.

 A prototype to explore and test different color picker configurations.